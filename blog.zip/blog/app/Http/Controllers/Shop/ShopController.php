<?php

namespace App\Http\Controllers\Shop;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\GoodsModel;
use App\Models\UserModel;
use App\Models\CodeModel;
use App\Models\Category;
use App\Models\Cart;
class ShopController extends Controller
{
    //所有商品
    public function shop(Request $request){
        $category=Category::where('level',1)->get();
        $data=GoodsModel::where('goods_shelf',1)->paginate(4);
        return view("Shop.shop",['category'=>$category,'data'=>$data]);
    }
    public function shops_cate(Request $request){
        $c_id=$request->input('c_id');
        $type=$request->input('type');
        $desc=$request->input('desc');
        $search=$request->input('search');
        if(!empty($search)){
            $where=[
                'goods_name'=>'like',"%$search%",
                'goods_shelf'=>1
            ];
        }else{
            $where=[
                'goods_shelf'=>1
            ];
        }
                $cate=Category::get()->toArray();
                $arr=$this->getson($cate,$c_id);
                if(!empty($type)){
                    $catearr=GoodsModel::whereIn('cate_id',$arr)->where($where)->orderBy($type,'desc')->paginate(4)->toArray()['data'];
                }else if(!empty($desc)){
                    if($desc==1){
                        $catearr=GoodsModel::whereIn('cate_id',$arr)->where($where)->orderBy('goods_price','asc')->paginate(4)->toArray()['data'];
                    }else{
                        $catearr=GoodsModel::whereIn('cate_id',$arr)->where($where)->orderBy('goods_price','desc')->paginate(4)->toArray()['data'];
                    }
                }else{
                    $catearr=GoodsModel::whereIn('cate_id',$arr)->where($where)->paginate(4)->toArray()['data'];
                }
        return view("Shop.shop_cate",['cate'=>$catearr]);
    }
    //商品详情
    public function shopcontent(Request $request){
        $goods_id=$request->input('goods_id');
        $where=[
            'goods_id'=>$goods_id
        ];
        //该商品
        $goods_data=GoodsModel::where($where)->get();
        //购物车购买数量
        $user_id=$user_id=$request->session()->get('user_id');
        $cartwhere=[
            'goods_id'=>$goods_id,
            'user_id'=>$user_id
        ];
        $cart_data=Cart::where($cartwhere)->get()->toArray();
        if(empty($cart_data)){
            $cart_data=0;
        }
        return view("Shop.shopcontent",['goods_data'=>$goods_data,'cart_data'=>$cart_data]);
    }
    //分类递归
    function getson($data,$id=0){
        static  $arr=[];
        foreach($data as $k=>$v){
            if($v['p_id']==$id){
                $arr[]=$v['cate_id'];
                $v['son']=$this->getson($data,$v['cate_id']);
            }
        }
        return $arr;
    }
}
