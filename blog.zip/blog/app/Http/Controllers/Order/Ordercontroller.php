<?php

namespace App\Http\Controllers\Order;

use Illuminate\Http\Request;
use App\Models\GoodsModel;
use App\Models\UserModel;
use App\Models\Cart;
use App\Models\Order_info;
use App\Models\Order_goods;
use App\Models\Region;
use App\Models\Address;
use App\Http\Controllers\Controller;

class Ordercontroller extends Controller
{
    public function order(Request $request){
        $user_id=$request->session()->get('user_id');
        $data=Order_info::where('user_id',$user_id)->get()->toArray();
        foreach ($data as $k=>$v){
            if($v['order_pay_type']==1){
                $data[$k]['order_pay_type']='线上支付';
            }else{
                $data[$k]['order_pay_type']='货到付款';
            }
            if($v['pay_status']==1){
                $data[$k]['pay_status']='未支付';
            }else{
                $data[$k]['pay_status']='已支付';
            }
            if($v['pay_way']==1){
                $data[$k]['pay_way']='支付宝';
            }else if($v['pay_way']==2){
                $data[$k]['pay_way']='微信';
            }else if($v['pay_way']==3){
                $data[$k]['pay_way']='网银';
            }else if($v['pay_way']==4){
                $data[$k]['pay_way']='网银支付';
            }else if($v['pay_way']==5){
                $data[$k]['pay_way']='货到付款';
            }
            if($v['order_status']==1){
                $data[$k]['order_status']='未支付';
            }else if($v['order_status']==2){
                $data[$k]['order_status']='已支付';
            }else if($v['order_status']==3){
                $data[$k]['order_status']='已确认';
            }else if($v['order_status']==4){
                $data[$k]['order_status']='备货中';
            }else if($v['order_status']==5){
                $data[$k]['order_status']='发货中';
            }else if($v['order_status']==6){
                $data[$k]['order_status']='已发货';
            }else if($v['order_status']==7){
                $data[$k]['order_status']='订单完成';
            }
        }
        $ishot=[
            'is_hot'=>1
        ];
        $goodshot=GoodsModel::where($ishot)->paginate(4);
        return view("Order.order",['data'=>$data,'goodshot'=>$goodshot]);
    }
}
