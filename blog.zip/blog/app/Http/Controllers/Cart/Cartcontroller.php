<?php

namespace App\Http\Controllers\Cart;

use Illuminate\Http\Request;
use App\Models\GoodsModel;
use App\Models\UserModel;
use App\Models\Cart;
use App\Http\Controllers\Controller;

class Cartcontroller extends Controller
{
    //添加购物车
    public function goods_cart(Request $request){
        $goods_id=$request->input('goods_id');
        $user_id=$request->session()->get('user_id');
        if(empty($user_id)){
            return json_encode([
                'code'=>2,
                'msg'=>'请先登陆'
            ]);
        }
        $goods=GoodsModel::where('goods_id',$goods_id)->get()->toArray()[0];
        if(empty($goods)){
            return json_encode([
                'code'=>0,
                'msg'=>'该商品不存在'
            ]);
        }else if($goods['goods_shelf']==0){
            return json_encode([
                'code'=>0,
                'msg'=>'该商品未上架'
            ]);
        }else if($goods['goods_number']==0){
            return json_encode([
                'code'=>0,
                'msg'=>'该商品没有库存了'
            ]);
        }
        $where=[
            'goods_id'=>$goods_id,
            'user_id'=>$user_id,
        ];
        $all=Cart::where($where)->get()->toArray();
        if(empty($all)){
            $array=[
                'goods_id'=>$goods_id,
                'user_id'=>$user_id,
                'c_time'=>time(),
                'buy_num'=>1,
                'status'=>0,
            ];
            $res=Cart::insert($array);
            if($res){
                return json_encode([
                    'code'=>1,
                    'msg'=>'添加购物车成功'
                ]);
            }else{
                return json_encode([
                    'code'=>0,
                    'msg'=>'添加购物车失败'
                ]);
            }
        }else{
            if($all[0]['buy_num']+1>$goods['goods_number']){
                return json_encode([
                    'code'=>0,
                    'msg'=>'该商品没有库存了'
                ]);
            }
            $array=[
                'goods_id'=>$goods_id,
                'user_id'=>$user_id,
                'c_time'=>time(),
                'buy_num'=>$all[0]['buy_num']+1,
                'status'=>0,
            ];
            $res=Cart::where('cart_id',$all[0]['cart_id'])->update($array);
            if($res){
                return json_encode([
                    'code'=>1,
                    'msg'=>'添加购物车成功'
                ]);
            }else{
                return json_encode([
                    'code'=>0,
                    'msg'=>'添加购物车失败'
                ]);
            }
        }

    }
    //购物车
    public function shop_cart(Request $request){
        $user_id=$request->session()->get('user_id');
        $where=[
            'user_id'=>$user_id,
            'is_del'=>0,
            'status'=>0
        ];
        $ishot=[
            'is_hot'=>1
        ];
        $goodshot=GoodsModel::where($ishot)->paginate(4);
        $cart=Cart::join('goods','goods.goods_id','=','cart.goods_id')->where($where)->get()->toArray();
        return view("Cart.shop_cart",['goods'=>$cart,'goodshot'=>$goodshot]);
    }
    public function cartdel(Request $request){
        $cart_id=$request->input('cart_id');
        foreach($cart_id as $k=>$v){
            $res=Cart::where('cart_id',$v)->update(['is_del'=>1]);
        }
        if($res){
            return json_encode([
                'code'=>1,
                'msg'=>'删除成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'删除失败'
            ]);
        }
    }
    //即点即改
    public function cartji(Request $request){
        $num=$request->input('num');
        $goods_id=$request->input('goods_id');
        $cart_id=$request->input('cart_id');
        $cartnum=[
            'buy_num'=>$num
        ];
        $where=[
            'cart_id'=>$cart_id
        ];
        $goods_num=GoodsModel::where('goods_id',$goods_id)->pluck('goods_number')->toArray()[0];
        if($num>$goods_num){
            return json_encode([
                'code'=>0,
                'msg'=>'该商品没有那么多库存',
                'num'=>$goods_num
            ]);
        }
        $res=Cart::where($where)->update($cartnum);
        if(!$res){
            return json_encode([
                'code'=>0,
                'msg'=>'修改失败',
                'num'=>$goods_num
            ]);
        }
    }
}
