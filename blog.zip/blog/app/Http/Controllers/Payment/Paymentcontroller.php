<?php

namespace App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use App\Models\GoodsModel;
use App\Models\UserModel;
use App\Models\Cart;
use App\Models\Order_info;
use App\Models\Order_goods;
use App\Models\Region;
use App\Models\Address;
use App\Http\Controllers\Controller;

class Paymentcontroller extends Controller
{
    //订单
    public function payment(Request $request)
    {
        $order_id = $request->input('order_id');
        $user_id = $user_id = $request->session()->get('user_id');
        $where = [
            'order_id' => $order_id,
            'user_id' => $user_id
        ];
        $arr = Order_goods::where($where)->get()->toArray();
        $order_price = Order_info::where($where)->get()->toArray()[0];
        return view("Payment.payment", ['arr' => $arr, 'order_price' => $order_price]);
    }

    //订单添加
    public function payment_do(Request $request)
    {
        $user_id = $user_id = $request->session()->get('user_id');
        if (empty($user_id)) {
            return json_encode([
                'code' => 0,
                'msg' => '请先登陆',
                'href' => 'login'
            ]);
        }
        $address=Address::where('user_id',$user_id)->count();
        if(empty($address)){
            return json_encode([
                'code' => 0,
                'msg' => '请先完善个人的地址信息',
                'href' => 'userpage'
            ]);
        }
        $cart_id = $request->input('cart_id');
        if (empty($cart_id)) {
            return json_encode([
                'code' => 0,
                'msg' => '最少选择一件商品',
                'href' => ''
            ]);
        }
        $cart = Cart::whereIn('cart_id', $cart_id)->join('goods', 'goods.goods_id', '=', 'cart.goods_id')->get()->toArray();
        //判断库存
        foreach ($cart as $k => $v) {
            if ($v['buy_num'] > $v['goods_number']) {
                $all[] = $v['goods_name'];
            }
        }
        if (!empty($all)) {
            return json_encode([
                'code' => 0,
                'msg' => implode(',', $all) . '----这些商品的库存不足,请先减少库存',
                'href' => ''
            ]);
        }
        //判断商品状态
        foreach ($cart as $k => $v) {
            if ($v['goods_shelf'] != 1) {
                $add[] = $v['goods_name'];
            }
            $money[] = $v['goods_price'] * $v['buy_num'];
        }
        if (!empty($add)) {
            return json_encode([
                'code' => 0,
                'msg' => '对不起，' . implode(',', $add) . '----这些商品的已下架,请删除这些商品',
                'href' => ''
            ]);
        }
        $order_sn = date("YmdHis", time()) . rand(1000, 9999);
        $where=[
            'user_id'=>$user_id,
            'is_onaddress'=>1
        ];
        $add_id=Address::where($where)->get()->toArray()[0]['address_id'];
        $array = [
            'order_sn' => $order_sn,
            'user_id' => $user_id,
            'order_status' => 1,
            'order_amount' => array_sum($money),
            'add_time' => time(),
            'pay_status' => 1,
            'order_pay_type' => 1,
            'pay_way' => 1,
            'add_id'=>$add_id
        ];
        $res = Order_info::insertGetId($array);
        if (!empty($res)) {
            Cart::whereIn('cart_id', $cart_id)->update(['status' => 1]);
            foreach ($cart as $k => $v) {
                $arr[] = [
                    'order_id' => $res,
                    'goods_id' => $v['goods_id'],
                    'goods_name' => $v['goods_name'],
                    'goods_sn' => $v['goods_sn'] ? $v['goods_sn'] : '',
                    'buy_number' => $v['buy_num'],
                    'shop_price' => $v['buy_num'] * $v['goods_price'],
                    'attr_values' => '',
                    'user_id' => $user_id,
                    'order_no' => $order_sn,
                    'goods_image' => $v['goods_img'] ? $v['goods_img'] : '',
                    'status' => ''
                ];
            }
            $order_goods = Order_goods::insert($arr);
            if ($order_goods) {
                return json_encode([
                    'code' => 1,
                    'msg' => '添加成功',
                    'order_id' => $res
                ]);
            } else {
                return json_encode([
                    'code' => 0,
                    'msg' => '添加失败',
                    'href' => ''
                ]);
            }
        }
    }

    //地址
    public function address(Request $request)
    {
        $user_id = $user_id = $request->session()->get('user_id');
        $where=[
            'user_id'=>$user_id,
            'is_del'=>0
        ];
        $data=Address::where('user_id',$user_id)->get()->toArray();
        return view("Payment.address",['data'=>$data]);
    }
    //添加地址
    public function address_do(Request $request)
    {
        return view("Payment.address_do");
    }
    public function add_do(Request $request){
        $data=$request->input('data');
        $user_id = $request->session()->get('user_id');
        $data['user_id']=$user_id;
        if($data['is_onaddress']==0){
            $data_id=Address::where('user_id',$user_id)->count();
            if(empty($data_id)){
                return json_encode([
                    'code'=>0,
                    'msg'=>'因您还没有默认地址,请选择默认'
                ]);
            }
            $add=Address::insertGetId($data);
            if(!empty($add)){
                $add_id=true;
            }else{
                $add_id=false;
            }
        }else{
            $add=Address::insertGetId($data);
            $address_id=Address::where('user_id',$user_id)->pluck('address_id')->toArray();
            $res=Address::whereIn('address_id',$address_id)->update(['is_onaddress'=>0]);
            $add_id=Address::where('address_id',$add)->update(['is_onaddress'=>1]);
        }
        if($add_id){
            return json_encode([
                'code'=>1,
                'msg'=>'添加成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'添加失败'
            ]);
        }
    }
    //删除地址
    public function  add_del(Request $request){
        $address_id=$request->input('address_id');
        $all=Address::where('address_id',$address_id)->get()->toArray()[0];
        if($all['is_onaddress']==1){
            return json_encode([
                'code'=>0,
                'msg'=>'请先修改默认地址，再次删除'
            ]);
        }
        $res=Address::where('address_id',$address_id)->update(['is_del'=>1]);
        if($res){
        return json_encode([
            'code'=>1,
            'msg'=>'删除成功'
        ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'删除失败'
            ]);
        }
    }
    //修改地址
    public function add_update(Request $request){
        $address_id=$request->input('address_id');
        $user_id = $user_id = $request->session()->get('user_id');
        $add_id=Address::where('user_id',$user_id)->pluck('address_id')->toArray();
        $res=Address::whereIn('address_id',$add_id)->update(['is_onaddress'=>0]);
        $add=Address::where('address_id',$address_id)->update(['is_onaddress'=>1]);
    }
    //编辑修改
    public function address_update(Request $request){
        $address_id=$request->input('address_id');
        $address=Address::where('address_id',$address_id)->get()->toArray();
        return view("Payment.address_update",['address'=>$address]);
    }
    //编辑修改执行
    public function add_update_do(Request $request){
        $data=$request->input('data');
        $res=Address::where('address_id',$data['address_id'])->update($data);
        if($res){
            return json_encode([
                'code'=>1,
                'msg'=>'保存成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'保存失败'
            ]);
        }
    }
}