<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\UserModel;
use App\Models\GoodsModel;
use App\Models\CodeModel;
use Illuminate\Support\Facades\DB;
class IndexController extends Controller
{
    //首页视图
    public function index(Request $request){
        //潮人推荐
        $arrGoods=GoodsModel::where('is_tell',1)->paginate(2);
        //猜你喜欢
        $data=GoodsModel::where('goods_shelf',1)->paginate(8);
        $count=count(GoodsModel::get());
        if($request->ajax()){
            return view("Index.index_do",['data'=>$data,'count'=>$count]);
        }else{
            return view("Index.index",['arrGoods'=>$arrGoods,'data'=>$data,'count'=>$count]);
        }


    }
    //注册视图
    public function register(){
        return view("Index.register");
    }
    //注册执行
    public function register_do(Request $request){
        $arrRegister=$request->input();
        $user_tel=$arrRegister['user_tel'];
        $user_pwd=$arrRegister['user_pwd'];
        $user_conpwd=$arrRegister['user_conpwd'];
        $user_code=$arrRegister['user_code'];
        //验证验证码
        $where=[
            'code_tel'=>$user_tel,
            'code_val'=>$user_code
        ];
        $arrcode=CodeModel::where($where)->first();
        if(empty($arrcode)){
            return json_encode([
                'code'=>0,
                'msg'=>'您的手机号或验证码不正确'
            ]);
        }
        //验证码时间
        $codetime=time();
        $code_time=$arrcode->code_time;
        if($codetime>$code_time){
            CodeModel::where(['code_tel'=>$user_tel,'code_val'=>$user_code])->update(['code_num'=>0]);
            return json_encode([
                'code'=>0,
                'msg'=>'您的验证码已过期，请重新获取'
            ]);
        }
        //用户唯一性验证
        $arrUser=UserModel::where(['user_tel'=>$user_tel])->first();
        if(!empty($arrUser)){
            return json_encode([
                'code'=>0,
                'msg'=>'该用户已注册'
            ]);
        };
        //确认密码
        if($user_pwd!=$user_conpwd){
            return json_encode([
                'code'=>0,
                'msg'=>'两次的密码不一致'
            ]);
        }
        //注册成功
        $arrData=[
            'user_tel'=>$user_tel,
            'user_pwd'=>md5($user_pwd),
            'user_code'=>$user_code,
            'create_time'=>time(),
        ];
        $bol=UserModel::insert($arrData);
        if($bol){
            CodeModel::where(['code_tel'=>$user_tel,'code_val'=>$user_code])->update(['code_num'=>2]);
            return json_encode([
                'code'=>1,
                'msg'=>'注册成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'注册失败'
            ]);
        }
    }
    //验证码
    public function register_code(Request $request){
        $tel=$request->input('user_tel');
        //获取验证码
        $obj= new \send();
        $code=$obj->show($tel);
        $arrcode=[
            'code_tel'=>$tel,
            'code_val'=>$code,
            'code_time'=>time()+60,
            'code_num'=>1,
        ];
        $rescode=CodeModel::insert($arrcode);
        if($rescode){
            return json_encode([
                'code'=>1,
                'msg'=>'发送验证码成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'发送验证码失败'
            ]);
        }
    }
    //登陆视图
    public function login(){
        return view("Index.login");
    }
    //登陆执行
    public function login_do(Request $request){
        $data=$request->input();
        $user_tel=$data['user_tel'];
        $user_pwd=$data['user_pwd'];
        $arr=[
            'user_tel'=>$user_tel,
            'user_pwd'=>md5($user_pwd),
        ];
        $arrUser=UserModel::where($arr)->first();
        if($arrUser){
            $user_id=$arrUser->user_id;
            $user_tel=$arrUser->user_tel;
            session(['user_id'=>$user_id,'user_tel'=>$user_tel]);
            return json_encode([
                'code'=>1,
                'msg'=>'登陆成功'
            ]);
        }else{
            return json_encode([
                'code'=>0,
                'msg'=>'登陆失败'
            ]);
        }
    }
    //个人中心视图
    public function userpage(Request $request){
        $data=$request->session()->get('user_tel');
        return view("Index.userpage",['data'=>$data]);
    }
    public function tuichu(Request $request){
        $request->session()->forget('user_id');
        $request->session()->forget('user_tel');
        return json_encode([
            'code'=>1,
            'msg'=>'退出成功'
        ]);
    }
}
