<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserModel extends Model
{
    //链接数据表
    protected $table='user';
    public $timestamps=false;
}
