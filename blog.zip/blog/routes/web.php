<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//首页
Route::get('index','Index\IndexController@index');
//注册
Route::get('register','Index\IndexController@register');
Route::post('register_do','Index\IndexController@register_do');//（注册执行）
Route::post('register_code','Index\IndexController@register_code');
//退出
Route::post('tuichu','Index\IndexController@tuichu');
//登陆
Route::get('login','Index\IndexController@login');
Route::post('login_do','Index\IndexController@login_do');//（登陆执行）
//个人中心
Route::get('userpage','Index\IndexController@userpage');
//所有商品
Route::get('shop','Shop\ShopController@shop');
Route::get('shops_cate','Shop\ShopController@shops_cate');
Route::get('shopcontent','Shop\ShopController@shopcontent');
//购物车
Route::get('shop_cart','Cart\Cartcontroller@shop_cart');
Route::post('goods_cart','Cart\Cartcontroller@goods_cart');
Route::post('cartdel','Cart\Cartcontroller@cartdel');//（购物车删除）
Route::post('cartji','Cart\Cartcontroller@cartji');//(加减的即点即改)
//订单
Route::get('payment','Payment\Paymentcontroller@payment');
Route::post('payment_do','Payment\Paymentcontroller@payment_do');
Route::get('address','Payment\Paymentcontroller@address');//(地址)
Route::get('address_do','Payment\Paymentcontroller@address_do');//(地址添加)
Route::post('add_do','Payment\Paymentcontroller@add_do');//(地址执行添加)
Route::post('add_del','Payment\Paymentcontroller@add_del');//(地址执行添加)
Route::post('add_update','Payment\Paymentcontroller@add_update');//(地址修改)
Route::get('address_update','Payment\Paymentcontroller@address_update');//(地址编辑)
Route::post('add_update_do','Payment\Paymentcontroller@add_update_do');//(地址编辑执行)
//潮购记录
Route::get('order','Order\Ordercontroller@order');





